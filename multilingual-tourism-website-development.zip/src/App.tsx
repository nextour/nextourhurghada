import { useEffect, useMemo, useState } from "react";
import {
  PlaneLanding,
  PlaneTakeoff,
  Sailboat,
  Sunset,
  Landmark,
  Car,
  MapPin,
  Clock,
  Users,
  Calendar,
  Phone,
  Mail,
  MessageCircle,
  Check,
  X,
  Menu,
  Settings,
  Star,
  ShieldCheck,
  CreditCard,
  Banknote,
  Globe,
  Wifi,
  Snowflake,
  Baby,
  Navigation,
  Camera,
  UtensilsCrossed,
  Fish,
  Mountain,
  Send,
  Copy,
  Luggage,
  ArrowRight,
  ArrowLeft,
  Wallet,
  Building2,
  BadgeCheck,
  Sparkles,
} from "lucide-react";
import { Lang, LANGS, IMAGES, getDict, DEFAULT_SETTINGS, OwnerSettings, TripKey } from "./translations";

const ZONE_PRICES: Record<string, number> = {
  hurghada: 12,
  sahl: 18,
  makadi: 22,
  gouna: 28,
  safaga: 28,
  soma: 32,
  marsa: 95,
};

const CAR_MULT: Record<string, number> = {
  tiggo4: 1,
  tiggo7: 1.3,
  hiace: 1.8,
};

export default function App() {
  const [lang, setLang] = useState<Lang>("ar");
  const t = getDict(lang);
  const isRTL = lang === "ar";

  const [settings, setSettings] = useState<OwnerSettings>(DEFAULT_SETTINGS);
  const [showOwner, setShowOwner] = useState(false);
  const [ownerDraft, setOwnerDraft] = useState<OwnerSettings>(DEFAULT_SETTINGS);
  const [ownerSavedMsg, setOwnerSavedMsg] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // calculator
  const [zone, setZone] = useState("makadi");
  const [carType, setCarType] = useState("tiggo4");
  const [tripMode, setTripMode] = useState<"oneway" | "round">("oneway");
  const [pax, setPax] = useState("2");

  // booking form
  const [form, setForm] = useState({
    name: "",
    contact: "",
    email: "",
    trip: "airport_to_hotel" as TripKey,
    date: "",
    time: "",
    flight: "",
    hotel: "",
    passengers: "2",
    luggage: "2",
    notes: "",
    pay: "cash",
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState(false);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
  }, [lang, isRTL]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("nextour_settings");
      if (raw) {
        const parsed = JSON.parse(raw);
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
        setOwnerDraft({ ...DEFAULT_SETTINGS, ...parsed });
      }
    } catch {}
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  const saveOwner = () => {
    const cleaned = {
      ...ownerDraft,
      whatsapp: ownerDraft.whatsapp.replace(/[^0-9]/g, "") || DEFAULT_SETTINGS.whatsapp,
    };
    setSettings(cleaned);
    localStorage.setItem("nextour_settings", JSON.stringify(cleaned));
    setOwnerSavedMsg(true);
    setTimeout(() => setOwnerSavedMsg(false), 3500);
    showToast(t.owner_saved);
  };

  const resetOwner = () => {
    setOwnerDraft(DEFAULT_SETTINGS);
    setSettings(DEFAULT_SETTINGS);
    localStorage.removeItem("nextour_settings");
    showToast(t.owner_reset);
  };

  const priceEstimate = useMemo(() => {
    const base = ZONE_PRICES[zone] ?? 15;
    const mult = CAR_MULT[carType] ?? 1;
    let price = base * mult;
    if (tripMode === "round") price = price * 2 * 0.9;
    return Math.round(price);
  }, [zone, carType, tripMode]);

  const tripLabel = (k: TripKey): string => {
    switch (k) {
      case "airport_to_hotel": return t.trip_airport_to_hotel;
      case "hotel_to_airport": return t.trip_hotel_to_airport;
      case "roundtrip": return t.trip_roundtrip;
      case "sea": return t.trip_sea;
      case "horse": return t.trip_horse;
      case "cairo": return t.trip_cairo;
      case "luxor": return t.trip_luxor;
    }
  };

  const payLabel = (k: string): string => {
    switch (k) {
      case "cash": return t.pay_cash;
      case "card": return t.pay_card;
      case "paypal": return t.pay_paypal;
      case "bank": return t.pay_bank;
      case "vodafone": return t.pay_vodafone;
      default: return k;
    }
  };

  const buildMessage = () => {
    const lines = [
      `NexTour Hurghada - ${t.book_title}`,
      `———————————`,
      `${t.f_name}: ${form.name}`,
      `${t.f_contact}: ${form.contact}`,
      form.email ? `Email: ${form.email}` : null,
      `${t.f_trip}: ${tripLabel(form.trip)}`,
      `${t.f_date}: ${form.date}`,
      `${t.f_time}: ${form.time}`,
      form.flight ? `${t.f_flight}: ${form.flight}` : null,
      `${t.f_hotel}: ${form.hotel}`,
      `${t.f_pax}: ${form.passengers} | ${t.f_luggage}: ${form.luggage}`,
      `${t.f_pay}: ${payLabel(form.pay)}`,
      form.notes ? `${t.f_notes}: ${form.notes}` : null,
    ].filter(Boolean);
    return lines.join("\n");
  };

  const waLink = (msg: string) => `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(msg)}`;
  const mailLink = (msg: string) =>
    `mailto:${settings.email}?subject=${encodeURIComponent(`NexTour Booking - ${form.name} - ${form.date}`)}&body=${encodeURIComponent(msg)}`;

  const validate = () => {
    if (!form.name.trim() || !form.contact.trim() || !form.date || !form.hotel.trim() || !form.trip) {
      setFormError(t.book_error);
      return false;
    }
    setFormError(null);
    return true;
  };

  const handleWaSend = () => {
    if (!validate()) return;
    setFormSuccess(true);
    window.open(waLink(buildMessage()), "_blank");
    showToast(t.book_success_t);
  };
  const handleMailSend = () => {
    if (!validate()) return;
    setFormSuccess(true);
    window.location.href = mailLink(buildMessage());
  };
  const handleCopy = async () => {
    if (!validate()) return;
    try {
      await navigator.clipboard.writeText(buildMessage());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast(buildMessage());
    }
  };

  const quickBook = (trip: TripKey) => {
    setForm((f) => ({ ...f, trip }));
    document.getElementById("booking")?.scrollIntoView({ behavior: "smooth" });
  };

  const Arrow = isRTL ? ArrowLeft : ArrowRight;

  const services = [
    {
      icon: PlaneLanding,
      color: "bg-[#0B1E2E]",
      img: IMAGES.airport,
      title: t.svc_airport_in_t,
      desc: t.svc_airport_in_d,
      price: "€12",
      unit: t.per_car,
      trip: "airport_to_hotel" as TripKey,
    },
    {
      icon: PlaneTakeoff,
      color: "bg-[#0E6B6B]",
      img: IMAGES.cityAerial,
      title: t.svc_airport_out_t,
      desc: t.svc_airport_out_d,
      price: "€12",
      unit: t.per_car,
      trip: "hotel_to_airport" as TripKey,
    },
    {
      icon: Sailboat,
      color: "bg-[#0EA5A4]",
      img: IMAGES.seaBoat,
      title: t.svc_sea_t,
      desc: t.svc_sea_d,
      price: "€25",
      unit: t.per_person,
      trip: "sea" as TripKey,
    },
    {
      icon: Sunset,
      color: "bg-[#C97A1A]",
      img: IMAGES.horseSunset,
      title: t.svc_horse_t,
      desc: t.svc_horse_d,
      price: "€20",
      unit: t.per_person,
      trip: "horse" as TripKey,
    },
    {
      icon: Landmark,
      color: "bg-[#8A6D1B]",
      img: IMAGES.cairo1,
      title: t.svc_cairo_t,
      desc: t.svc_cairo_d,
      price: "€65",
      unit: t.per_person,
      trip: "cairo" as TripKey,
    },
    {
      icon: Landmark,
      color: "bg-[#5B3E0B]",
      img: IMAGES.luxor1,
      title: t.svc_luxor_t,
      desc: t.svc_luxor_d,
      price: "€60",
      unit: t.per_person,
      trip: "luxor" as TripKey,
    },
  ];

  const reviews = useMemo(() => {
    if (lang === "ar")
      return [
        { name: "أحمد الشريف — القاهرة", text: "السائق كان في انتظارنا بلوحة باسمنا حتى مع تأخير الطيارة ساعة. العربية التيجو 8 نضيفة ومكيفة والسواق محترم جداً. أفضل نقل جربته في الغردقة.", stars: 5, trip: "مطار → سهل حشيش" },
        { name: "عائلة الحربي — السعودية", text: "حجزنا ذهاب وعودة ويوم الأقصر. التزام بالمواعيد بالدقيقة، مقاعد أطفال مجانية، والسعر مثل ما اتفقنا واتساب بدون زيادة. شكراً نكستور!", stars: 5, trip: "ذهاب وعودة + الأقصر" },
        { name: "منى وعمر — الإمارات", text: "رحلة البحر كانت منظمة والغداء ممتاز، وركوب الخيل وقت الغروب تجربة لا تنسى. التواصل واتساب سريع ويردوا عربي وإنجليزي.", stars: 5, trip: "بحرية + خيل" },
      ];
    if (lang === "de")
      return [
        { name: "Familie Schneider — Berlin", text: "Fahrer wartete mit Namensschild trotz 1h Verspätung. Tiggo 8 sauber, klimatisiert, sehr höflich. Bester Transfer in Hurghada!", stars: 5, trip: "Flughafen → Sahl Hasheesh" },
        { name: "Thomas & Petra — München", text: "Hin & zurück plus Luxor gebucht. Pünktlich auf die Minute, Kindersitze gratis, Preis wie per WhatsApp vereinbart. Danke NexTour!", stars: 5, trip: "Hin & zurück + Luxor" },
        { name: "Julia K. — Hamburg", text: "Bootstour top organisiert, Mittagessen lecker, Reiten bei Sonnenuntergang unvergesslich. WhatsApp-Antwort in Minuten auf Deutsch.", stars: 5, trip: "Boot + Reiten" },
      ];
    if (lang === "fr")
      return [
        { name: "Famille Dubois — Paris", text: "Chauffeur avec pancarte malgré 1h de retard. Tiggo 8 propre et climatisée, très poli. Meilleur transfert à Hurghada !", stars: 5, trip: "Aéroport → Sahl Hasheesh" },
        { name: "Karim & Sara — Lyon", text: "Aller-retour + Louxor réservés. Ponctuel à la minute, sièges enfant gratuits, prix respecté comme sur WhatsApp. Merci NexTour !", stars: 5, trip: "Aller-retour + Louxor" },
        { name: "Sophie M. — Marseille", text: "Excursion mer parfaite, déjeuner excellent, équitation au sunset inoubliable. Réponse WhatsApp en minutes en français.", stars: 5, trip: "Mer + Cheval" },
      ];
    return [
      { name: "Schneider Family — Berlin", text: "Driver waited with name board despite 1h delay. Tiggo 8 clean, air-conditioned, very polite. Best transfer in Hurghada!", stars: 5, trip: "Airport → Sahl Hasheesh" },
      { name: "Ahmed & Family — Cairo", text: "Booked round trip + Luxor. On-time to the minute, free child seats, price exactly as agreed on WhatsApp. Thanks NexTour!", stars: 5, trip: "Round trip + Luxor" },
      { name: "Emma W. — London", text: "Sea trip well organized, lunch great, sunset horse riding unforgettable. WhatsApp reply in minutes in English.", stars: 5, trip: "Sea + Horse" },
    ];
  }, [lang]);

  const faqs = useMemo(() => {
    if (lang === "ar")
      return [
        { q: "كيف ألاقي السائق في مطار الغردقة؟", a: "سائقنا ينتظرك عند باب صالة الوصول بلوحة عليها اسمك + لوجو NexTour، ويرسل لك واتساب برقم العربية ومكانه أول ما تهبط. انتظار 60 دقيقة مجاناً." },
        { q: "ما هي سياراتكم؟ هل هي حديثة ومكيفة؟", a: "أسطولنا الأساسي شيري Tiggo 8 Pro موديل 2023-2025: 7 مقاعد، تكييف أمامي وخلفي، شنطة واسعة، واي فاي، وتعقيم بعد كل رحلة. للمجموعات نوفر هايس VIP." },
        { q: "كيف أدفع؟ هل لازم عربون؟", a: "للنقل الخاص لا نطلب مقدماً — تدفع كاش (يورو/دولار/جنيه) أو فيزا عند الوصول. للرحلات اليومية (القاهرة/الأقصر/البحر) يمكنك الدفع مقدماً PayPal/تحويل أو كاش يوم الرحلة." },
        { q: "ماذا لو تأخرت طائرتي أو تغير الفندق؟", a: "نتتبع رحلتك تلقائياً ونعدل موعد الاستلام مجاناً. غيّر الفندق أو الموعد برسالة واتساب وسنؤكد لك فوراً بدون رسوم حتى قبل 24 ساعة." },
        { q: "هل الرحلات مناسبة للأطفال؟", a: "نعم — مقاعد أطفال مجانية في النقل، والرحلات البحرية والخيل مناسبة من عمر 6 سنوات مع مرافق. أخبرنا بأعمار الأطفال في ملاحظات الحجز." },
      ];
    if (lang === "de")
      return [
        { q: "Wie finde ich den Fahrer am Flughafen Hurghada?", a: "Unser Fahrer wartet am Ausgang mit Namensschild + NexTour-Logo und sendet Ihnen per WhatsApp Wagennummer und Standort. 60 Min. Warten gratis." },
        { q: "Welche Autos nutzen Sie?", a: "Hauptsächlich Chery Tiggo 8 Pro 2023–2025: 7 Sitze, Front- & Heckklima, großer Kofferraum, WLAN, Desinfektion nach jeder Fahrt. Für Gruppen Hiace VIP." },
        { q: "Wie zahle ich? Anzahlung nötig?", a: "Privattranfers ohne Vorauszahlung — bar (EUR/USD/EGP) oder Visa bei Ankunft. Tagestouren per PayPal/Überweisung im Voraus oder bar am Tourtag." },
        { q: "Was bei Flugverspätung oder Hotelwechsel?", a: "Wir tracken Ihren Flug automatisch und passen die Abholung gratis an. Hotel/Zeit per WhatsApp ändern — kostenfrei bis 24h vorher." },
        { q: "Sind Touren für Kinder geeignet?", a: "Ja — Kindersitze gratis im Transfer, Boot & Reiten ab 6 Jahren mit Begleitung. Alter der Kinder einfach in Notizen angeben." },
      ];
    if (lang === "fr")
      return [
        { q: "Comment trouver le chauffeur à l'aéroport d'Hurghada ?", a: "Notre chauffeur vous attend à la sortie avec pancarte + logo NexTour et vous envoie WhatsApp avec plaque et position. 60 min d'attente offertes." },
        { q: "Quelles voitures utilisez-vous ?", a: "Principalement Chery Tiggo 8 Pro 2023–2025 : 7 places, double clim, grand coffre, WiFi, désinfection après chaque trajet. Hiace VIP pour groupes." },
        { q: "Comment payer ? Acompte obligatoire ?", a: "Transferts privés sans acompte — cash (EUR/USD/EGP) ou Visa à l'arrivée. Excursions par PayPal/virement à l'avance ou cash le jour J." },
        { q: "En cas de retard de vol ou changement d'hôtel ?", a: "Nous suivons votre vol et ajustons gratuitement. Changez hôtel/heure par WhatsApp — sans frais jusqu'à 24h avant." },
        { q: "Excursions adaptées aux enfants ?", a: "Oui — sièges enfant gratuits, mer & cheval dès 6 ans accompagnés. Indiquez les âges dans les notes." },
      ];
    return [
      { q: "How do I find the driver at Hurghada Airport?", a: "Our driver waits at arrivals exit with your name board + NexTour logo and WhatsApps you the car plate and location. 60 min waiting free." },
      { q: "What cars do you use?", a: "Mainly Chery Tiggo 8 Pro 2023–2025: 7 seats, front & rear A/C, big trunk, WiFi, sanitized after every trip. Hiace VIP for groups." },
      { q: "How do I pay? Deposit needed?", a: "Private transfers need no prepayment — cash (EUR/USD/EGP) or Visa on arrival. Day tours via PayPal/transfer in advance or cash on tour day." },
      { q: "What if my flight is delayed or hotel changes?", a: "We track your flight automatically and adjust pickup free. Change hotel/time via WhatsApp — free until 24h before." },
      { q: "Are tours kid-friendly?", a: "Yes — free child seats in transfers, sea & horse from age 6 with companion. Just add kids' ages in notes." },
    ];
  }, [lang]);

  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className={`min-h-screen bg-[#FAF7F0] text-[#0B1E2E] ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
      {/* TOP BAR */}
      <div className="bg-[#0B1E2E] text-white text-[13px]">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 truncate">
            <BadgeCheck className="w-4 h-4 text-[#E3B64B] shrink-0" />
            <span className="truncate">{t.topbar}</span>
          </p>
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a href={`tel:${settings.phone}`} className="flex items-center gap-1.5 hover:text-[#E3B64B]">
              <Phone className="w-3.5 h-3.5" /> <span dir="ltr">{settings.phone}</span>
            </a>
            <span className="opacity-30">|</span>
            <a href={`mailto:${settings.email}`} className="flex items-center gap-1.5 hover:text-[#E3B64B]">
              <Mail className="w-3.5 h-3.5" /> <span>{settings.email}</span>
            </a>
          </div>
        </div>
      </div>

      {/* NAVBAR */}
      <header className="sticky top-0 z-40 bg-[#FAF7F0]/95 backdrop-blur border-b border-[#0B1E2E]/10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <a href="#home" className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#0B1E2E] flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 texture-dots opacity-60" />
              <span className="relative text-[#E3B64B] font-black text-xl leading-none">N</span>
              <span className="absolute bottom-1.5 w-6 h-[3px] bg-[#0EA5A4] rounded-full" />
            </div>
            <div className="leading-tight">
              <p className="font-black text-xl tracking-tight">NexTour <span className="text-[#0EA5A4]">نكستور</span></p>
              <p className="text-[11px] font-semibold tracking-[0.18em] text-[#0B1E2E]/60 uppercase">Hurghada • Red Sea</p>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-6 text-[15px] font-bold">
            <a href="#home" className="hover:text-[#0EA5A4]">{t.nav_home}</a>
            <a href="#services" className="hover:text-[#0EA5A4]">{t.nav_services}</a>
            <a href="#fleet" className="hover:text-[#0EA5A4]">{t.nav_fleet}</a>
            <a href="#tours" className="hover:text-[#0EA5A4]">{t.nav_trips}</a>
            <a href="#prices" className="hover:text-[#0EA5A4]">{t.nav_prices}</a>
            <a href="#booking" className="hover:text-[#0EA5A4]">{t.nav_booking}</a>
          </nav>

          <div className="flex items-center gap-2">
            {/* language switcher */}
            <div className="flex items-center bg-white border border-[#0B1E2E]/15 rounded-full p-1 gap-1">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  title={l.label}
                  className={`px-2.5 py-1.5 rounded-full text-[12px] font-black transition ${lang === l.code ? "bg-[#0B1E2E] text-white" : "text-[#0B1E2E]/60 hover:text-[#0B1E2E]"}`}
                >
                  {l.short}
                </button>
              ))}
            </div>
            <button
              onClick={() => { setOwnerDraft(settings); setShowOwner(true); }}
              className="hidden md:flex items-center gap-1.5 text-[13px] font-bold px-3 py-2 rounded-full border border-[#0B1E2E]/15 hover:bg-white"
            >
              <Settings className="w-4 h-4" /> {t.owner_btn}
            </button>
            <a
              href="#booking"
              className="hidden sm:flex items-center gap-2 bg-[#0EA5A4] hover:bg-[#0B8A89] text-white font-black px-5 py-2.5 rounded-full text-[14px]"
            >
              {t.nav_booking}
            </a>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="lg:hidden p-2 rounded-full border border-[#0B1E2E]/15 bg-white">
              {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
        {mobileMenu && (
          <div className="lg:hidden border-t border-[#0B1E2E]/10 bg-white px-4 py-4 space-y-1 font-bold">
            {[
              ["#home", t.nav_home],
              ["#services", t.nav_services],
              ["#fleet", t.nav_fleet],
              ["#tours", t.nav_trips],
              ["#prices", t.nav_prices],
              ["#booking", t.nav_booking],
              ["#contact", t.nav_contact],
            ].map(([h, label]) => (
              <a key={h} href={h} onClick={() => setMobileMenu(false)} className="block px-3 py-2.5 rounded-xl hover:bg-[#FAF7F0]">
                {label}
              </a>
            ))}
            <button
              onClick={() => { setMobileMenu(false); setOwnerDraft(settings); setShowOwner(true); }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-[#0B1E2E] text-white"
            >
              <Settings className="w-4 h-4" /> {t.owner_btn}
            </button>
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="home" className="relative overflow-hidden bg-[#0B1E2E] text-white">
        <div className="absolute inset-0">
          <img src={IMAGES.hero} alt="Hurghada" className="w-full h-full object-cover opacity-70" />
          <div className="absolute inset-0 bg-[#0B1E2E]/55" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 pt-12 pb-10 lg:pt-20 lg:pb-16 grid lg:grid-cols-[1.15fr_0.85fr] gap-10 items-center">
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-[13px] font-bold backdrop-blur">
              <Sparkles className="w-4 h-4 text-[#E3B64B]" />
              {t.hero_badge}
            </div>
            <h1 className="mt-5 text-4xl sm:text-5xl lg:text-[58px] font-black leading-[1.15]">
              {t.hero_title_a}
              <br />
              <span className="text-[#E3B64B]">{t.hero_title_b}</span>
            </h1>
            <p className="mt-5 text-white/85 text-[16px] lg:text-[18px] leading-relaxed max-w-xl">{t.hero_sub}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href="#booking" className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1EBE5B] text-white font-black px-7 py-3.5 rounded-full text-[16px]">
                <MessageCircle className="w-5 h-5" /> {t.hero_cta_book}
              </a>
              <a href="#prices" className="flex items-center gap-2 bg-white text-[#0B1E2E] font-black px-7 py-3.5 rounded-full text-[16px] hover:bg-[#F3ECDD]">
                <Navigation className="w-5 h-5" /> {t.hero_cta_prices}
              </a>
            </div>
            <p className="mt-4 text-[13px] text-white/70 font-semibold flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#E3B64B]" /> {t.hero_note}
            </p>
            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl">
              {[
                ["25K+", t.stat_transfers],
                ["18K+", t.stat_travelers],
                ["4.9★", t.stat_rating],
                ["24/7", t.stat_support],
              ].map(([v, l]) => (
                <div key={l} className="bg-white/10 border border-white/15 rounded-2xl px-4 py-3 backdrop-blur text-center">
                  <p className="font-black text-xl text-[#E3B64B]" dir="ltr">{v}</p>
                  <p className="text-[12px] text-white/75 font-bold mt-0.5">{l}</p>
                </div>
              ))}
            </div>
          </div>

          {/* quick booking card */}
          <div className="bg-white text-[#0B1E2E] rounded-3xl p-6 shadow-2xl animate-float-slow">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-black text-lg">{t.hero_card_t}</p>
                <p className="text-[13px] text-[#0B1E2E]/60 font-semibold">{t.hero_card_pick}</p>
              </div>
              <div className="w-11 h-11 rounded-full bg-[#0EA5A4]/15 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-[#0EA5A4]" />
              </div>
            </div>
            <div className="mt-4 space-y-3">
              <label className="block">
                <span className="text-[13px] font-black">{t.f_trip}</span>
                <select
                  value={form.trip}
                  onChange={(e) => setForm({ ...form, trip: e.target.value as TripKey })}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]"
                >
                  {(["airport_to_hotel", "hotel_to_airport", "roundtrip", "sea", "horse", "cairo", "luxor"] as TripKey[]).map((k) => (
                    <option key={k} value={k}>{tripLabel(k)}</option>
                  ))}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-[13px] font-black">{t.f_date}</span>
                  <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]" />
                </label>
                <label className="block">
                  <span className="text-[13px] font-black">{t.f_time}</span>
                  <input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]" />
                </label>
              </div>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_hotel}</span>
                <input value={form.hotel} onChange={(e) => setForm({ ...form, hotel: e.target.value })} placeholder={t.f_hotel_ph}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-semibold text-[14px] outline-none focus:border-[#0EA5A4]" />
              </label>
              <a href="#booking" className="flex items-center justify-center gap-2 w-full bg-[#0B1E2E] hover:bg-[#16405e] text-white font-black py-3.5 rounded-xl">
                {t.book_btn} <Arrow className="w-4 h-4" />
              </a>
              <div className="flex items-center justify-center gap-4 text-[12px] font-bold text-[#0B1E2E]/60">
                <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-green-600" /> Tiggo 8</span>
                <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-green-600" /> {t.free_cancel}</span>
                <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-green-600" /> 24/7</span>
              </div>
            </div>
          </div>
        </div>

        {/* trust strip */}
        <div className="relative border-t border-white/15 bg-[#0B1E2E]/80 backdrop-blur">
          <div className="max-w-7xl mx-auto px-4 py-5 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              [BadgeCheck, t.trust_1_t, t.trust_1_d],
              [Car, t.trust_2_t, t.trust_2_d],
              [Users, t.trust_3_t, t.trust_3_d],
              [Wallet, t.trust_4_t, t.trust_4_d],
            ].map(([Icon, title, desc]: any) => (
              <div key={title} className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#E3B64B] flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-[#0B1E2E]" />
                </div>
                <div>
                  <p className="font-black text-[14px]">{title}</p>
                  <p className="text-[12px] text-white/65 font-semibold">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="max-w-7xl mx-auto px-4 py-14 lg:py-20">
        <div className="text-center max-w-2xl mx-auto">
          <p className="inline-flex items-center gap-2 text-[13px] font-black tracking-wide text-[#0EA5A4] bg-[#0EA5A4]/10 px-4 py-1.5 rounded-full">
            <Globe className="w-4 h-4" /> {t.services_kicker}
          </p>
          <h2 className="mt-4 text-3xl lg:text-[42px] font-black leading-tight">{t.services_title}</h2>
          <p className="mt-3 text-[#0B1E2E]/65 font-semibold leading-relaxed">{t.services_sub}</p>
        </div>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s) => (
            <div key={s.title} className="group bg-white rounded-3xl overflow-hidden border border-[#0B1E2E]/10 hover:shadow-xl hover:-translate-y-1 transition-all">
              <div className="relative h-48 overflow-hidden">
                <img src={s.img} alt={s.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
                <div className="absolute top-3 start-3 flex items-center gap-2">
                  <span className={`${s.color} text-white text-[12px] font-black px-3 py-1.5 rounded-full flex items-center gap-1.5`}>
                    <s.icon className="w-3.5 h-3.5" /> {t.private_car}
                  </span>
                </div>
                <div className="absolute bottom-3 end-3 bg-white rounded-full px-3 py-1.5 text-[13px] font-black flex items-center gap-1">
                  <span className="text-[#0B1E2E]/50 font-bold">{t.from_label}</span> <span className="text-[#0EA5A4]">{s.price}</span> <span className="text-[11px] text-[#0B1E2E]/50">{s.unit}</span>
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-black text-[18px] leading-snug">{s.title}</h3>
                <p className="mt-2 text-[14px] text-[#0B1E2E]/65 leading-relaxed font-medium min-h-[66px]">{s.desc}</p>
                <div className="mt-4 flex gap-2">
                  <button onClick={() => quickBook(s.trip)} className="flex-1 flex items-center justify-center gap-2 bg-[#0B1E2E] hover:bg-[#0EA5A4] text-white font-black py-3 rounded-xl text-[14px] transition">
                    {t.book_btn} <Arrow className="w-4 h-4" />
                  </button>
                  <a href="#booking" onClick={() => setForm((f) => ({ ...f, trip: s.trip }))} className="px-4 py-3 rounded-xl border border-[#0B1E2E]/15 font-black text-[14px] hover:bg-[#FAF7F0]">
                    {t.details_btn}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FLEET */}
      <section id="fleet" className="bg-[#0B1E2E] text-white py-14 lg:py-20 relative overflow-hidden">
        <div className="absolute inset-0 texture-dots opacity-40 pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#E3B64B] bg-white/10 px-4 py-1.5 rounded-full border border-white/15">
                <Car className="w-4 h-4" /> {t.fleet_kicker}
              </p>
              <h2 className="mt-4 text-3xl lg:text-[40px] font-black leading-tight">{t.fleet_title}</h2>
              <p className="mt-3 text-white/70 font-medium leading-relaxed">{t.fleet_sub}</p>
              <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  [Users, t.spec_seats],
                  [Luggage, t.spec_luggage],
                  [Snowflake, t.spec_ac],
                  [Wifi, t.spec_wifi],
                  [Baby, t.spec_child],
                  [Navigation, t.spec_tracker],
                ].map(([Icon, label]: any) => (
                  <div key={label} className="flex items-center gap-2.5 bg-white/10 border border-white/15 rounded-2xl px-3 py-2.5">
                    <Icon className="w-5 h-5 text-[#E3B64B] shrink-0" />
                    <span className="text-[13px] font-bold leading-tight">{label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={() => quickBook("airport_to_hotel")} className="flex items-center gap-2 bg-[#E3B64B] hover:bg-[#d1a63f] text-[#0B1E2E] font-black px-6 py-3 rounded-full">
                  {t.book_btn} <Arrow className="w-4 h-4" />
                </button>
                <a href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 border border-white/25 hover:bg-white/10 font-black px-6 py-3 rounded-full">
                  <MessageCircle className="w-5 h-5" /> {t.chat_now}
                </a>
              </div>
            </div>
            <div className="grid gap-4">
              <div className="rounded-3xl overflow-hidden border border-white/15">
                <img src={IMAGES.suvFront} alt="Tiggo 8" className="w-full h-64 object-cover" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <img src={IMAGES.suvInterior} alt="Interior" className="w-full h-40 object-cover rounded-3xl border border-white/15" />
                <img src={IMAGES.suvStreet} alt="Tiggo street" className="w-full h-40 object-cover rounded-3xl border border-white/15" />
              </div>
            </div>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-4">
            {[
              { t: t.fleet_card1_t, d: t.fleet_card1_d },
              { t: t.fleet_card2_t, d: t.fleet_card2_d },
              { t: t.fleet_card3_t, d: t.fleet_card3_d },
            ].map((c) => (
              <div key={c.t} className="bg-white text-[#0B1E2E] rounded-2xl p-5 flex gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#0B1E2E] flex items-center justify-center shrink-0">
                  <Car className="w-5 h-5 text-[#E3B64B]" />
                </div>
                <div>
                  <p className="font-black">{c.t}</p>
                  <p className="text-[13px] text-[#0B1E2E]/60 font-semibold mt-1 leading-relaxed">{c.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICE CALCULATOR */}
      <section id="prices" className="max-w-7xl mx-auto px-4 py-14 lg:py-20">
        <div className="bg-white rounded-[28px] border border-[#0B1E2E]/10 overflow-hidden grid lg:grid-cols-2">
          <div className="p-7 lg:p-10">
            <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#0EA5A4] bg-[#0EA5A4]/10 px-4 py-1.5 rounded-full">
              <CreditCard className="w-4 h-4" /> {t.calc_kicker}
            </p>
            <h2 className="mt-4 text-3xl font-black">{t.calc_title}</h2>
            <p className="mt-2 text-[#0B1E2E]/60 font-semibold text-[14px] leading-relaxed">{t.calc_sub}</p>

            <div className="mt-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1.5"><PlaneLanding className="w-4 h-4 text-[#0EA5A4]" /> {t.calc_from}</span>
                  <div className="mt-1.5 px-3 py-3 rounded-xl bg-[#FAF7F0] border border-[#0B1E2E]/10 font-bold text-[14px]">HRG - Hurghada Airport</div>
                </label>
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1.5"><MapPin className="w-4 h-4 text-[#0EA5A4]" /> {t.calc_to}</span>
                  <select value={zone} onChange={(e) => setZone(e.target.value)} className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]">
                    <option value="hurghada">{t.zone_hurghada}</option>
                    <option value="sahl">{t.zone_sahl}</option>
                    <option value="makadi">{t.zone_makadi}</option>
                    <option value="gouna">{t.zone_gouna}</option>
                    <option value="soma">{t.zone_soma}</option>
                    <option value="safaga">{t.zone_safaga}</option>
                    <option value="marsa">{t.zone_marsa}</option>
                  </select>
                </label>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1.5"><Car className="w-4 h-4 text-[#0EA5A4]" /> {t.calc_car}</span>
                  <select value={carType} onChange={(e) => setCarType(e.target.value)} className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]">
                    <option value="tiggo4">{t.car_tiggo4}</option>
                    <option value="tiggo7">{t.car_tiggo7}</option>
                    <option value="hiace">{t.car_hiace}</option>
                  </select>
                </label>
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1.5"><Users className="w-4 h-4 text-[#0EA5A4]" /> {t.calc_pax}</span>
                  <select value={pax} onChange={(e) => setPax(e.target.value)} className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none focus:border-[#0EA5A4]">
                    {["1", "2", "3", "4", "5", "6", "7", "8+"].map((n) => (
                      <option key={n} value={n}>{n} {n === "1" ? t.adult : ""}</option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setTripMode("oneway")} className={`py-3 rounded-xl font-black text-[14px] border ${tripMode === "oneway" ? "bg-[#0B1E2E] text-white border-[#0B1E2E]" : "border-[#0B1E2E]/15 hover:bg-[#FAF7F0]"}`}>
                  {t.calc_oneway}
                </button>
                <button onClick={() => setTripMode("round")} className={`py-3 rounded-xl font-black text-[14px] border ${tripMode === "round" ? "bg-[#0EA5A4] text-white border-[#0EA5A4]" : "border-[#0B1E2E]/15 hover:bg-[#FAF7F0]"}`}>
                  {t.calc_round}
                </button>
              </div>
              <p className="text-[12px] text-[#0B1E2E]/55 font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-green-600" /> {t.calc_note}
              </p>
            </div>
          </div>
          <div className="bg-[#0B1E2E] text-white p-7 lg:p-10 flex flex-col justify-center relative overflow-hidden">
            <div className="absolute inset-0 texture-dots opacity-30" />
            <div className="relative">
              <p className="text-[13px] font-bold text-white/60">{t.calc_estimate}</p>
              <p className="mt-2 flex items-end gap-2" dir="ltr">
                <span className="text-6xl font-black text-[#E3B64B]">€{priceEstimate}</span>
                <span className="mb-2 text-white/60 font-bold text-[14px]">{tripMode === "round" ? t.calc_round : t.calc_oneway}</span>
              </p>
              <div className="mt-5 bg-white/10 border border-white/15 rounded-2xl p-4 text-[13px] font-semibold space-y-2">
                <p className="flex justify-between"><span className="text-white/60">{t.calc_to}</span><span>{ { hurghada: t.zone_hurghada, sahl: t.zone_sahl, makadi: t.zone_makadi, gouna: t.zone_gouna, soma: t.zone_soma, safaga: t.zone_safaga, marsa: t.zone_marsa }[zone]}</span></p>
                <p className="flex justify-between"><span className="text-white/60">{t.calc_car}</span><span>{{ tiggo4: t.car_tiggo4, tiggo7: t.car_tiggo7, hiace: t.car_hiace }[carType]}</span></p>
                <p className="flex justify-between"><span className="text-white/60">{t.calc_pax}</span><span>{pax}</span></p>
              </div>
              <a
                href={waLink(`${t.calc_estimate}: €${priceEstimate} | HRG → ${zone} | ${carType} | ${pax} pax | ${tripMode}`)}
                target="_blank" rel="noreferrer"
                className="mt-5 flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1EBE5B] font-black py-4 rounded-2xl"
              >
                <MessageCircle className="w-5 h-5" /> {t.calc_book}
              </a>
              <p className="mt-3 text-center text-[12px] text-white/55 font-semibold" dir="ltr">WhatsApp: {settings.whatsapp} • {settings.email}</p>
            </div>
          </div>
        </div>
      </section>

      {/* TOURS: CAIRO & LUXOR */}
      <section id="tours" className="bg-white border-y border-[#0B1E2E]/10 py-14 lg:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto">
            <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#8A6D1B] bg-[#E3B64B]/15 px-4 py-1.5 rounded-full">
              <Landmark className="w-4 h-4" /> {t.trips_kicker}
            </p>
            <h2 className="mt-4 text-3xl lg:text-[42px] font-black">{t.trips_title}</h2>
            <p className="mt-3 text-[#0B1E2E]/60 font-semibold">{t.trips_sub}</p>
          </div>

          <div className="mt-10 grid lg:grid-cols-2 gap-6">
            {/* Cairo */}
            <div className="rounded-[28px] overflow-hidden border border-[#0B1E2E]/10 bg-[#FAF7F0]">
              <div className="relative h-64">
                <img src={IMAGES.cairo2} alt="Cairo" className="w-full h-full object-cover" />
                <span className="absolute top-4 start-4 bg-[#E3B64B] text-[#0B1E2E] text-[12px] font-black px-3 py-1.5 rounded-full">{t.cairo_badge}</span>
                <span className="absolute bottom-4 end-4 bg-white rounded-full px-4 py-2 font-black text-[14px]">{t.from_label} <span className="text-[#0EA5A4]">€65</span></span>
              </div>
              <div className="p-6 lg:p-8">
                <h3 className="text-2xl font-black">{t.cairo_title}</h3>
                <p className="mt-2 text-[14px] text-[#0B1E2E]/65 leading-relaxed font-medium">{t.cairo_desc}</p>
                <div className="mt-4 flex flex-wrap gap-2 text-[12px] font-black">
                  {[t.cairo_meta1, t.cairo_meta2, t.cairo_meta3].map((m) => (
                    <span key={m} className="bg-white border border-[#0B1E2E]/10 px-3 py-1.5 rounded-full flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-[#0EA5A4]" />{m}</span>
                  ))}
                </div>
                <ul className="mt-4 space-y-2 text-[14px] font-bold">
                  {[t.cairo_inc1, t.cairo_inc2, t.cairo_inc3].map((inc) => (
                    <li key={inc} className="flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center shrink-0"><Check className="w-3.5 h-3.5 text-green-700" /></span>{inc}</li>
                  ))}
                </ul>
                <div className="mt-5 grid grid-cols-3 gap-2">
                  {[IMAGES.cairo1, IMAGES.cairo3, IMAGES.cairo2].map((src) => (
                    <img key={src} src={src} alt="Cairo" className="h-20 w-full object-cover rounded-xl" />
                  ))}
                </div>
                <button onClick={() => quickBook("cairo")} className="mt-5 w-full flex items-center justify-center gap-2 bg-[#0B1E2E] hover:bg-[#0EA5A4] text-white font-black py-3.5 rounded-2xl transition">
                  {t.book_btn} — {t.trip_cairo} <Arrow className="w-4 h-4" />
                </button>
              </div>
            </div>
            {/* Luxor */}
            <div className="rounded-[28px] overflow-hidden border border-[#0B1E2E]/10 bg-[#0B1E2E] text-white">
              <div className="relative h-64">
                <img src={IMAGES.luxor2} alt="Luxor" className="w-full h-full object-cover" />
                <span className="absolute top-4 start-4 bg-white text-[#0B1E2E] text-[12px] font-black px-3 py-1.5 rounded-full">{t.luxor_badge}</span>
                <span className="absolute bottom-4 end-4 bg-[#E3B64B] text-[#0B1E2E] rounded-full px-4 py-2 font-black text-[14px]">{t.from_label} €60</span>
              </div>
              <div className="p-6 lg:p-8">
                <h3 className="text-2xl font-black">{t.luxor_title}</h3>
                <p className="mt-2 text-[14px] text-white/70 leading-relaxed font-medium">{t.luxor_desc}</p>
                <div className="mt-4 flex flex-wrap gap-2 text-[12px] font-black">
                  {[t.luxor_meta1, t.luxor_meta2, t.luxor_meta3].map((m) => (
                    <span key={m} className="bg-white/10 border border-white/15 px-3 py-1.5 rounded-full flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-[#E3B64B]" />{m}</span>
                  ))}
                </div>
                <ul className="mt-4 space-y-2 text-[14px] font-bold">
                  {[t.cairo_inc1, t.cairo_inc2, t.cairo_inc3].map((inc) => (
                    <li key={inc} className="flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-[#E3B64B] flex items-center justify-center shrink-0"><Check className="w-3.5 h-3.5 text-[#0B1E2E]" /></span>{inc}</li>
                  ))}
                </ul>
                <div className="mt-5 grid grid-cols-3 gap-2">
                  {[IMAGES.luxor1, IMAGES.luxor3, IMAGES.luxor2].map((src) => (
                    <img key={src} src={src} alt="Luxor" className="h-20 w-full object-cover rounded-xl border border-white/15" />
                  ))}
                </div>
                <button onClick={() => quickBook("luxor")} className="mt-5 w-full flex items-center justify-center gap-2 bg-[#E3B64B] hover:bg-[#d1a63f] text-[#0B1E2E] font-black py-3.5 rounded-2xl transition">
                  {t.book_btn} — {t.trip_luxor} <Arrow className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Sea & Horse */}
          <div className="mt-6 grid lg:grid-cols-2 gap-6">
            <div className="rounded-[28px] overflow-hidden border border-[#0B1E2E]/10 bg-[#EAF6F5] p-6 lg:p-8 grid sm:grid-cols-[1fr_220px] gap-6 items-center">
              <div>
                <p className="flex items-center gap-2 text-[#0E6B6B] font-black text-[13px]"><Sailboat className="w-4 h-4" /> {t.svc_sea_t} • {t.best_seller}</p>
                <h3 className="mt-2 text-xl font-black leading-snug">{t.sea_title}</h3>
                <p className="mt-2 text-[14px] text-[#0B1E2E]/65 font-medium leading-relaxed">{t.sea_desc}</p>
                <ul className="mt-3 space-y-1.5 text-[13px] font-bold">
                  {[t.sea_f1, t.sea_f2, t.sea_f3].map((f, i) => (
                    <li key={f} className="flex items-center gap-2">
                      {[UtensilsCrossed, Fish, Camera][i] && <span className="w-7 h-7 rounded-full bg-white flex items-center justify-center shrink-0 border border-[#0B1E2E]/10">{i === 0 ? <UtensilsCrossed className="w-3.5 h-3.5 text-[#0EA5A4]" /> : i === 1 ? <Fish className="w-3.5 h-3.5 text-[#0EA5A4]" /> : <Camera className="w-3.5 h-3.5 text-[#0EA5A4]" />}</span>}
                      {f}
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex items-center gap-3">
                  <button onClick={() => quickBook("sea")} className="flex items-center gap-2 bg-[#0EA5A4] hover:bg-[#0B8A89] text-white font-black px-5 py-3 rounded-full text-[14px]">
                    {t.book_btn} €25 <Arrow className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="space-y-3">
                <img src={IMAGES.seaYacht} alt="yacht" className="rounded-2xl h-36 w-full object-cover" />
                <img src={IMAGES.seaIsland} alt="island" className="rounded-2xl h-28 w-full object-cover" />
              </div>
            </div>

            <div className="rounded-[28px] overflow-hidden border border-[#0B1E2E]/10 bg-[#FFF4E0] p-6 lg:p-8 grid sm:grid-cols-[1fr_220px] gap-6 items-center">
              <div>
                <p className="flex items-center gap-2 text-[#9A5B00] font-black text-[13px]"><Sunset className="w-4 h-4" /> {t.svc_horse_t} • Tiggo 8 Transfer</p>
                <h3 className="mt-2 text-xl font-black leading-snug">{t.horse_title}</h3>
                <p className="mt-2 text-[14px] text-[#0B1E2E]/65 font-medium leading-relaxed">{t.horse_desc}</p>
                <ul className="mt-3 space-y-1.5 text-[13px] font-bold">
                  {[t.horse_f1, t.horse_f2, t.horse_f3].map((f) => (
                    <li key={f} className="flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-white border border-[#0B1E2E]/10 flex items-center justify-center shrink-0"><Check className="w-3.5 h-3.5 text-[#C97A1A]" /></span>{f}</li>
                  ))}
                </ul>
                <div className="mt-4 flex items-center gap-3">
                  <button onClick={() => quickBook("horse")} className="flex items-center gap-2 bg-[#0B1E2E] hover:bg-[#C97A1A] hover:text-white text-white font-black px-5 py-3 rounded-full text-[14px] transition">
                    {t.book_btn} €20 <Arrow className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="space-y-3">
                <img src={IMAGES.horseSunset} alt="horse" className="rounded-2xl h-36 w-full object-cover" />
                <img src={IMAGES.horseBeach} alt="horse beach" className="rounded-2xl h-28 w-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HOW */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <div className="text-center">
          <p className="text-[13px] font-black text-[#0EA5A4] bg-[#0EA5A4]/10 inline-flex px-4 py-1.5 rounded-full">{t.how_kicker}</p>
          <h2 className="mt-3 text-3xl font-black">{t.how_title}</h2>
        </div>
        <div className="mt-8 grid md:grid-cols-3 gap-4">
          {[
            { n: "1", title: t.how_1_t, desc: t.how_1_d, icon: Calendar },
            { n: "2", title: t.how_2_t, desc: t.how_2_d, icon: MessageCircle },
            { n: "3", title: t.how_3_t, desc: t.how_3_d, icon: Wallet },
          ].map((s) => (
            <div key={s.n} className="bg-white rounded-3xl border border-[#0B1E2E]/10 p-6 text-center relative">
              <span className="absolute top-4 end-5 text-5xl font-black text-[#0B1E2E]/5">{s.n}</span>
              <div className="w-14 h-14 mx-auto rounded-2xl bg-[#0B1E2E] flex items-center justify-center">
                <s.icon className="w-6 h-6 text-[#E3B64B]" />
              </div>
              <p className="mt-4 font-black text-lg">{s.title}</p>
              <p className="mt-1.5 text-[14px] text-[#0B1E2E]/60 font-semibold leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* BOOKING */}
      <section id="booking" className="bg-[#0B1E2E] text-white py-14 lg:py-20 relative overflow-hidden">
        <div className="absolute inset-0 texture-dots opacity-30" />
        <div className="relative max-w-7xl mx-auto px-4 grid lg:grid-cols-[0.9fr_1.1fr] gap-8">
          <div>
            <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#0B1E2E] bg-[#E3B64B] px-4 py-1.5 rounded-full">
              <Calendar className="w-4 h-4" /> {t.book_kicker}
            </p>
            <h2 className="mt-4 text-3xl lg:text-[40px] font-black leading-tight">{t.book_title}</h2>
            <p className="mt-3 text-white/70 font-medium leading-relaxed">{t.book_sub}</p>

            <div className="mt-6 space-y-3">
              <a href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noreferrer" className="flex items-center gap-4 bg-white/10 border border-white/15 rounded-2xl p-4 hover:bg-white/15">
                <span className="w-11 h-11 rounded-full bg-[#25D366] flex items-center justify-center shrink-0 animate-pulse-ring"><MessageCircle className="w-5 h-5 text-white" /></span>
                <span><span className="block font-black">WhatsApp</span><span className="text-[13px] text-white/65 font-bold" dir="ltr">+{settings.whatsapp}</span></span>
              </a>
              <a href={`mailto:${settings.email}`} className="flex items-center gap-4 bg-white/10 border border-white/15 rounded-2xl p-4 hover:bg-white/15">
                <span className="w-11 h-11 rounded-full bg-[#0EA5A4] flex items-center justify-center shrink-0"><Mail className="w-5 h-5 text-white" /></span>
                <span><span className="block font-black">Email</span><span className="text-[13px] text-white/65 font-bold">{settings.email}</span></span>
              </a>
              <div className="flex items-center gap-4 bg-white/10 border border-white/15 rounded-2xl p-4">
                <span className="w-11 h-11 rounded-full bg-[#E3B64B] flex items-center justify-center shrink-0"><Phone className="w-5 h-5 text-[#0B1E2E]" /></span>
                <span><span className="block font-black">{t.footer_contact}</span><span className="text-[13px] text-white/65 font-bold" dir="ltr">{settings.phone}</span></span>
              </div>
            </div>

            <div className="mt-6 rounded-2xl overflow-hidden border border-white/15">
              <img src={IMAGES.sunsetBay} alt="Hurghada sunset" className="h-44 w-full object-cover" />
            </div>
          </div>

          <div className="bg-white text-[#0B1E2E] rounded-[28px] p-6 lg:p-8">
            {formSuccess && (
              <div className="mb-5 bg-green-50 border border-green-200 rounded-2xl p-4 flex gap-3">
                <span className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center shrink-0"><Check className="w-5 h-5 text-white" /></span>
                <div>
                  <p className="font-black text-green-800">{t.book_success_t}</p>
                  <p className="text-[13px] text-green-700 font-semibold">{t.book_success_d}</p>
                </div>
              </div>
            )}
            {formError && (
              <div className="mb-5 bg-red-50 border border-red-200 rounded-2xl p-4 text-red-700 font-bold text-[14px] flex gap-2">
                <X className="w-5 h-5 shrink-0" /> {formError}
              </div>
            )}
            <div className="grid sm:grid-cols-2 gap-4">
              <label className="block">
                <span className="text-[13px] font-black">{t.f_name}</span>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t.f_name_ph}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-semibold outline-none focus:border-[#0EA5A4]" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_contact}</span>
                <input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} placeholder={t.f_contact_ph} dir="ltr"
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-semibold outline-none focus:border-[#0EA5A4] text-left" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_email}</span>
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="name@mail.com" dir="ltr"
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-semibold outline-none focus:border-[#0EA5A4] text-left" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_trip}</span>
                <select value={form.trip} onChange={(e) => setForm({ ...form, trip: e.target.value as TripKey })}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-bold outline-none focus:border-[#0EA5A4]">
                  {(["airport_to_hotel", "hotel_to_airport", "roundtrip", "sea", "horse", "cairo", "luxor"] as TripKey[]).map((k) => (
                    <option key={k} value={k}>{tripLabel(k)}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="text-[13px] font-black flex items-center gap-1"><Calendar className="w-3.5 h-3.5 text-[#0EA5A4]" /> {t.f_date}</span>
                <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="mt-1.5 w-full rounded-xl border-2 border-[#0EA5A4]/30 bg-[#EAF6F5] px-3 py-3 text-[14px] font-black outline-none focus:border-[#0EA5A4]" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-[#0EA5A4]" /> {t.f_time}</span>
                <input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })}
                  className="mt-1.5 w-full rounded-xl border-2 border-[#0EA5A4]/30 bg-[#EAF6F5] px-3 py-3 text-[14px] font-black outline-none focus:border-[#0EA5A4]" dir="ltr" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_flight}</span>
                <input value={form.flight} onChange={(e) => setForm({ ...form, flight: e.target.value })} placeholder={t.f_flight_ph} dir="ltr"
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-semibold outline-none focus:border-[#0EA5A4] text-left" />
              </label>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_hotel}</span>
                <input value={form.hotel} onChange={(e) => setForm({ ...form, hotel: e.target.value })} placeholder={t.f_hotel_ph}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-semibold outline-none focus:border-[#0EA5A4]" />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {t.f_pax}</span>
                  <select value={form.passengers} onChange={(e) => setForm({ ...form, passengers: e.target.value })}
                    className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none">
                    {["1", "2", "3", "4", "5", "6", "7", "8+"].map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-[13px] font-black flex items-center gap-1"><Luggage className="w-3.5 h-3.5" /> {t.f_luggage}</span>
                  <select value={form.luggage} onChange={(e) => setForm({ ...form, luggage: e.target.value })}
                    className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none">
                    {["0", "1", "2", "3", "4", "5", "6+"].map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </label>
              </div>
              <label className="block">
                <span className="text-[13px] font-black">{t.f_pay}</span>
                <select value={form.pay} onChange={(e) => setForm({ ...form, pay: e.target.value })}
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-[14px] outline-none">
                  <option value="cash">{t.pay_cash}</option>
                  <option value="card">{t.pay_card}</option>
                  <option value="paypal">{t.pay_paypal}</option>
                  <option value="bank">{t.pay_bank}</option>
                  <option value="vodafone">{t.pay_vodafone}</option>
                </select>
              </label>
            </div>
            <label className="block mt-4">
              <span className="text-[13px] font-black">{t.f_notes}</span>
              <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder={t.f_notes_ph} rows={3}
                className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-medium outline-none focus:border-[#0EA5A4] resize-none" />
            </label>

            <div className="mt-5 grid sm:grid-cols-2 gap-3">
              <button onClick={handleWaSend} className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1EBE5B] text-white font-black py-4 rounded-2xl text-[15px]">
                <MessageCircle className="w-5 h-5" /> {t.send_whatsapp}
              </button>
              <button onClick={handleMailSend} className="flex items-center justify-center gap-2 bg-[#0B1E2E] hover:bg-[#16405e] text-white font-black py-4 rounded-2xl text-[15px]">
                <Send className="w-5 h-5" /> {t.send_email}
              </button>
            </div>
            <button onClick={handleCopy} className="mt-3 w-full flex items-center justify-center gap-2 border border-[#0B1E2E]/15 hover:bg-[#FAF7F0] font-black py-3 rounded-2xl text-[14px]">
              <Copy className="w-4 h-4" /> {copied ? t.copied : t.copy_msg}
            </button>

            {/* live preview */}
            <div className="mt-5 rounded-2xl bg-[#FAF7F0] border border-[#0B1E2E]/10 p-4">
              <p className="text-[12px] font-black text-[#0B1E2E]/50 mb-2">WhatsApp Preview • {settings.whatsapp}:</p>
              <pre className="text-[12px] font-mono whitespace-pre-wrap leading-relaxed text-[#0B1E2E]/80" dir="auto">{buildMessage() || "..."}</pre>
            </div>
          </div>
        </div>
      </section>

      {/* PAYMENTS */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <div className="text-center max-w-2xl mx-auto">
          <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#0EA5A4] bg-[#0EA5A4]/10 px-4 py-1.5 rounded-full"><Wallet className="w-4 h-4" /> {t.payments_kicker}</p>
          <h2 className="mt-3 text-3xl font-black">{t.payments_title}</h2>
          <p className="mt-2 text-[#0B1E2E]/60 font-semibold text-[14px]">{t.payments_sub}</p>
        </div>
        <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { on: settings.payCash, icon: Banknote, label: t.pay_cash, desc: "EUR / USD / EGP" },
            { on: settings.payCard, icon: CreditCard, label: t.pay_card, desc: "Visa • Mastercard" },
            { on: settings.payPaypal, icon: Wallet, label: t.pay_paypal, desc: "PayPal" },
            { on: settings.payBank, icon: Building2, label: t.pay_bank, desc: "IBAN / SWIFT" },
            { on: settings.payVodafone, icon: Phone, label: t.pay_vodafone, desc: "010 • InstaPay" },
          ].map((m) => (
            <div key={m.label} className={`rounded-2xl border p-5 text-center ${m.on ? "bg-white border-[#0B1E2E]/10" : "bg-[#0B1E2E]/5 border-dashed border-[#0B1E2E]/15 opacity-50"}`}>
              <div className={`w-12 h-12 mx-auto rounded-2xl flex items-center justify-center ${m.on ? "bg-[#0B1E2E]" : "bg-[#0B1E2E]/10"}`}>
                <m.icon className={`w-6 h-6 ${m.on ? "text-[#E3B64B]" : "text-[#0B1E2E]/40"}`} />
              </div>
              <p className="mt-3 font-black text-[14px] leading-tight">{m.label}</p>
              <p className="text-[12px] text-[#0B1E2E]/55 font-bold mt-1" dir="ltr">{m.desc}</p>
              <p className="mt-2 text-[11px] font-black">{m.on ? <span className="text-green-700 bg-green-100 px-2 py-0.5 rounded-full">● Active</span> : <span className="text-[#0B1E2E]/40">○ Off</span>}</p>
            </div>
          ))}
        </div>
        {(settings.extraInfo || true) && (
          <div className="mt-5 bg-[#FFF7E0] border border-[#E3B64B]/40 rounded-2xl p-5 flex gap-3">
            <ShieldCheck className="w-6 h-6 text-[#8A6D1B] shrink-0" />
            <div>
              <p className="font-black text-[#5B3E0B]">{t.pay_note_t}</p>
              {settings.extraInfo ? (
                <p className="mt-1 text-[14px] font-semibold text-[#5B3E0B]/80 whitespace-pre-wrap leading-relaxed" dir="auto">{settings.extraInfo}</p>
              ) : (
                <p className="mt-1 text-[13px] font-semibold text-[#5B3E0B]/60">
                  {lang === "ar" && "الدفع كاش أو فيزا عند الوصول — الأطفال تحت 5 سنوات مجاناً — خصم 10% لرحلة الذهاب والعودة. (يمكن لصاحب الصفحة تعديل هذه الرسالة من لوحة المالك)"}
                  {lang === "en" && "Pay cash or Visa on arrival — kids under 5 free — 10% round-trip discount. (Owner can edit this note from Owner Panel)"}
                  {lang === "de" && "Zahlung bar oder Visa bei Ankunft — Kinder unter 5 gratis — 10% Hin-&-zurück-Rabatt. (Inhaber kann diesen Hinweis im Inhaber-Bereich ändern)"}
                  {lang === "fr" && "Paiement cash ou Visa à l'arrivée — enfants -5 ans gratuits — -10% aller-retour. (Le propriétaire peut modifier cette note depuis l'espace propriétaire)"}
                </p>
              )}
            </div>
          </div>
        )}
      </section>

      {/* REVIEWS + FAQ */}
      <section className="bg-white border-y border-[#0B1E2E]/10 py-14">
        <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-10">
          <div>
            <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#8A6D1B] bg-[#E3B64B]/15 px-4 py-1.5 rounded-full"><Star className="w-4 h-4" /> {t.reviews_kicker}</p>
            <h2 className="mt-3 text-2xl lg:text-3xl font-black">{t.reviews_title}</h2>
            <div className="mt-6 space-y-4">
              {reviews.map((r) => (
                <div key={r.name} className="bg-[#FAF7F0] border border-[#0B1E2E]/10 rounded-2xl p-5">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: r.stars }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#E3B64B] text-[#E3B64B]" />
                    ))}
                    <span className="ms-2 text-[12px] font-black text-[#0B1E2E]/50">{r.trip}</span>
                  </div>
                  <p className="mt-2 text-[14px] font-medium leading-relaxed text-[#0B1E2E]/80">“{r.text}”</p>
                  <p className="mt-2 font-black text-[13px]">— {r.name}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="inline-flex items-center gap-2 text-[13px] font-black text-[#0EA5A4] bg-[#0EA5A4]/10 px-4 py-1.5 rounded-full"><MessageCircle className="w-4 h-4" /> {t.faq_kicker}</p>
            <h2 className="mt-3 text-2xl lg:text-3xl font-black">{t.faq_title}</h2>
            <div className="mt-6 space-y-3">
              {faqs.map((f, i) => (
                <div key={i} className={`border rounded-2xl overflow-hidden ${openFaq === i ? "border-[#0EA5A4] bg-[#EAF6F5]" : "border-[#0B1E2E]/10 bg-[#FAF7F0]"}`}>
                  <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between gap-3 px-5 py-4 font-black text-[15px] text-start">
                    {f.q}
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${openFaq === i ? "bg-[#0B1E2E] text-white" : "bg-white border border-[#0B1E2E]/15"}`}>
                      {openFaq === i ? <X className="w-4 h-4" /> : <span className="text-lg leading-none">+</span>}
                    </span>
                  </button>
                  {openFaq === i && <p className="px-5 pb-5 text-[14px] font-medium text-[#0B1E2E]/70 leading-relaxed">{f.a}</p>}
                </div>
              ))}
            </div>
            <div className="mt-6 grid grid-cols-3 gap-3">
              {[IMAGES.beachUmbrellas, IMAGES.seaCoral, IMAGES.heroSunset].map((src) => (
                <img key={src} src={src} alt="Hurghada" className="h-24 w-full object-cover rounded-2xl" />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CONTACT / FOOTER */}
      <footer id="contact" className="bg-[#0B1E2E] text-white pt-14 pb-6 relative overflow-hidden">
        <div className="absolute inset-0 texture-dots opacity-20" />
        <div className="relative max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-1">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#E3B64B] flex items-center justify-center">
                  <span className="text-[#0B1E2E] font-black text-xl">N</span>
                </div>
                <div>
                  <p className="font-black text-lg">NexTour نكستور</p>
                  <p className="text-[11px] tracking-[0.18em] text-white/50 font-bold">HURGHADA • RED SEA</p>
                </div>
              </div>
              <p className="mt-4 text-[14px] text-white/65 font-medium leading-relaxed">{t.footer_about}</p>
              <div className="mt-4 flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-4 h-4 fill-[#E3B64B] text-[#E3B64B]" />)}
                <span className="ms-2 text-[12px] font-bold text-white/60">4.9 • 2800+ {t.reviews_count}</span>
              </div>
            </div>
            <div>
              <p className="font-black text-[#E3B64B]">{t.footer_links}</p>
              <ul className="mt-3 space-y-2 text-[14px] font-semibold text-white/70">
                {[["#home", t.nav_home], ["#services", t.nav_services], ["#fleet", t.nav_fleet], ["#tours", t.nav_trips], ["#prices", t.nav_prices], ["#booking", t.nav_booking]].map(([h, l]) => (
                  <li key={h}><a href={h} className="hover:text-white">{l}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-black text-[#E3B64B]">{t.footer_services}</p>
              <ul className="mt-3 space-y-2 text-[14px] font-semibold text-white/70">
                {[t.trip_airport_to_hotel, t.trip_hotel_to_airport, t.trip_sea, t.trip_horse, t.trip_cairo, t.trip_luxor].map((s) => (
                  <li key={s} className="flex items-center gap-2"><Mountain className="w-3.5 h-3.5 text-[#0EA5A4]" />{s}</li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-black text-[#E3B64B]">{t.footer_contact}</p>
              <div className="mt-3 space-y-3 text-[14px] font-bold">
                <a href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noreferrer" className="flex items-center gap-2.5 bg-[#25D366] rounded-xl px-4 py-3 text-white hover:bg-[#1EBE5B]">
                  <MessageCircle className="w-5 h-5" /> <span dir="ltr">+{settings.whatsapp}</span>
                </a>
                <a href={`mailto:${settings.email}`} className="flex items-center gap-2.5 bg-white/10 border border-white/15 rounded-xl px-4 py-3 hover:bg-white/15 break-all">
                  <Mail className="w-5 h-5 text-[#E3B64B] shrink-0" /> {settings.email}
                </a>
                <p className="flex items-center gap-2.5 text-white/70"><Phone className="w-4 h-4" /> <span dir="ltr">{settings.phone}</span></p>
                <p className="flex items-center gap-2.5 text-white/70"><MapPin className="w-4 h-4" /> Hurghada, Red Sea, Egypt</p>
                <button onClick={() => { setOwnerDraft(settings); setShowOwner(true); }} className="flex items-center gap-2 text-[12px] text-white/50 hover:text-white border border-white/15 rounded-full px-4 py-2">
                  <Settings className="w-3.5 h-3.5" /> {t.owner_btn}
                </button>
              </div>
            </div>
          </div>
          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-[13px] text-white/50 font-semibold">
            <p>{t.rights}</p>
            <p className="flex items-center gap-2">
              <Car className="w-4 h-4 text-[#E3B64B]" /> Tiggo 8 Pro • Hiace VIP • {t.contact_sub}
            </p>
          </div>
        </div>
      </footer>

      {/* FLOATING WHATSAPP */}
      <a
        href={waLink(lang === "ar" ? "أهلاً نكستور، عايز أحجز رحلة" : lang === "de" ? "Hallo NexTour, ich möchte eine Tour buchen" : lang === "fr" ? "Bonjour NexTour, je veux réserver" : "Hello NexTour, I want to book")}
        target="_blank" rel="noreferrer"
        className="fixed bottom-5 end-5 z-40 flex items-center gap-2 bg-[#25D366] hover:bg-[#1EBE5B] text-white font-black pl-4 pe-5 py-3.5 rounded-full shadow-2xl"
      >
        <MessageCircle className="w-6 h-6" />
        <span className="hidden sm:inline text-[14px]">{t.chat_now}</span>
      </a>

      {/* OWNER MODAL */}
      {showOwner && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowOwner(false)} />
          <div className="relative bg-white w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-6 lg:p-8 text-[#0B1E2E]">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="w-12 h-12 rounded-2xl bg-[#0B1E2E] flex items-center justify-center shrink-0"><Settings className="w-6 h-6 text-[#E3B64B]" /></span>
                <div>
                  <h3 className="font-black text-xl">{t.owner_panel_t}</h3>
                  <p className="text-[13px] text-[#0B1E2E]/60 font-semibold mt-0.5">{t.owner_panel_d}</p>
                </div>
              </div>
              <button onClick={() => setShowOwner(false)} className="p-2 rounded-full bg-[#FAF7F0] border border-[#0B1E2E]/10 hover:bg-red-50"><X className="w-5 h-5" /></button>
            </div>

            {ownerSavedMsg && (
              <div className="mt-4 bg-green-50 border border-green-200 rounded-2xl p-3.5 flex items-center gap-2 text-green-800 font-black text-[14px]">
                <Check className="w-5 h-5" /> {t.owner_saved}
              </div>
            )}

            <div className="mt-5 grid sm:grid-cols-2 gap-4">
              <label className="block sm:col-span-1">
                <span className="text-[13px] font-black flex items-center gap-1.5"><MessageCircle className="w-4 h-4 text-[#25D366]" /> {t.owner_whatsapp}</span>
                <input value={ownerDraft.whatsapp} onChange={(e) => setOwnerDraft({ ...ownerDraft, whatsapp: e.target.value })} dir="ltr"
                  placeholder="201012345678" className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-left outline-none focus:border-[#25D366]" />
                <span className="text-[11px] text-[#0B1E2E]/50 font-semibold">e.g. 201012345678</span>
              </label>
              <label className="block sm:col-span-1">
                <span className="text-[13px] font-black flex items-center gap-1.5"><Mail className="w-4 h-4 text-[#0EA5A4]" /> {t.owner_email}</span>
                <input value={ownerDraft.email} onChange={(e) => setOwnerDraft({ ...ownerDraft, email: e.target.value })} dir="ltr"
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-semibold text-left outline-none focus:border-[#0EA5A4]" />
              </label>
              <label className="block sm:col-span-2">
                <span className="text-[13px] font-black flex items-center gap-1.5"><Phone className="w-4 h-4" /> {t.owner_phone}</span>
                <input value={ownerDraft.phone} onChange={(e) => setOwnerDraft({ ...ownerDraft, phone: e.target.value })} dir="ltr"
                  className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 font-bold text-left outline-none" />
              </label>
            </div>

            <p className="mt-5 font-black text-[14px]">{t.owner_methods}</p>
            <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                ["payCash", t.pay_cash, Banknote],
                ["payCard", t.pay_card, CreditCard],
                ["payPaypal", t.pay_paypal, Wallet],
                ["payBank", t.pay_bank, Building2],
                ["payVodafone", t.pay_vodafone, Phone],
              ].map(([key, label, Icon]: any) => (
                <label key={key} className={`flex items-center gap-3 rounded-xl border px-3 py-3 cursor-pointer ${ (ownerDraft as any)[key] ? "border-[#0EA5A4] bg-[#EAF6F5]" : "border-[#0B1E2E]/15 bg-[#FAF7F0] opacity-70"}`}>
                  <input type="checkbox" checked={(ownerDraft as any)[key]} onChange={(e) => setOwnerDraft({ ...ownerDraft, [key]: e.target.checked })} className="w-5 h-5 accent-[#0EA5A4]" />
                  <Icon className="w-5 h-5" />
                  <span className="font-bold text-[14px]">{label}</span>
                </label>
              ))}
            </div>

            <label className="block mt-5">
              <span className="text-[13px] font-black">{t.owner_extra}</span>
              <textarea value={ownerDraft.extraInfo} onChange={(e) => setOwnerDraft({ ...ownerDraft, extraInfo: e.target.value })} rows={4} placeholder={t.owner_extra_ph}
                className="mt-1.5 w-full rounded-xl border border-[#0B1E2E]/15 bg-[#FAF7F0] px-3 py-3 text-[14px] font-medium outline-none focus:border-[#0EA5A4] resize-none" dir="auto" />
            </label>

            <p className="mt-3 text-[12px] text-[#0B1E2E]/50 font-semibold">{t.owner_hint}</p>

            <div className="mt-5 flex flex-col sm:flex-row gap-3">
              <button onClick={saveOwner} className="flex-1 flex items-center justify-center gap-2 bg-[#0EA5A4] hover:bg-[#0B8A89] text-white font-black py-4 rounded-2xl">
                <Check className="w-5 h-5" /> {t.owner_save}
              </button>
              <button onClick={resetOwner} className="px-6 py-4 rounded-2xl border border-[#0B1E2E]/15 font-black hover:bg-[#FAF7F0]">{t.owner_reset}</button>
              <button onClick={() => setShowOwner(false)} className="px-6 py-4 rounded-2xl bg-[#0B1E2E] text-white font-black">{t.owner_close}</button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST */}
      {toast && (
        <div className="fixed bottom-24 start-1/2 -translate-x-1/2 z-50 bg-[#0B1E2E] text-white font-black px-6 py-3.5 rounded-full shadow-2xl flex items-center gap-2 text-[14px] animate-fade-up">
          <Check className="w-5 h-5 text-[#25D366]" /> {toast}
        </div>
      )}
    </div>
  );
}
